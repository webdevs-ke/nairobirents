<?php 
class Rental {
    public $info, $agentPhone;

    function __construct ($row, $phone) {
        $this->info = $row;
        $this->agentPhone = $phone;
    }
}

class DB {
    public $conn = null;

    function __construct ($host, $user, $pw, $db) {
        $this->conn = new mysqli ($host, $user, $pw, $db);

        if($this->conn->connect_error) {
            die("Connection failure, CALL: +254708793131 to resolve, ".$this->conn->connect_error);
        }
    }

    function close() {
        if($this->conn) {
            $this->conn->close();
        }
    }
}

function getRows ($table, $cols, $where = array (), $order_by = array (), $limit = 0) {
    $rows = array ();
    $db = new DB("localhost", "root", "", "nyumba");
    $sql = "select ".$cols." from ".$table;
    if (count($where)) {
        $sql .= " where ".$where[0]." ".$where[1]." ".$where[2];
    }
    if (count($order_by)) {
        $sql .= " order by ".$order_by[0]." ".$order_by[1];
    }
    if ($limit) {
        $sql .= " limit ".$limit;
    }
    $res = $db->conn->query($sql);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
    }    
    $db->conn->close();
    return $rows;
}

function getRowsQuery ($q) {
    $rows = array ();
    $db = new DB("localhost", "root", "", "nyumba");
    $res = $db->conn->query($q);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
    }    
    $db->conn->close();
    return $rows;
}

function getRow ($table, $cols, $where) {
    $row = array ();
    $db = new DB("localhost", "root", "", "nyumba");
    $res = $db->conn->query("select ".$cols." from ".$table." where ".$where[0]." ".$where[1]." ".$where[2]);
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = $r;
        }
    }    
    $db->conn->close();
    return $row;
}

function getMaxValue ($table, $col) {
    $maxVal = 0;
    $col = 'max('.$col.')';
    $db = new DB("localhost", "root", "", "nyumba");    
    $res = $db->conn->query("select ".$col." from ".$table);
    while ($r = $res->fetch_assoc()) {
        $maxVal = $r[$col];
    }
    $db->conn->close();
    return $maxVal;
}

function writeQuery ($q) {
    $db = new DB("localhost", "root", "", "nyumba");
    $db->conn->query($q);
    $db->conn->close();
}

function updateRow ($table, $set, $where) {
    writeQuery ("update ".$table." set ".$set." where ".$where[0]." = ".$where[1]);
}

function insertRow ($table, $query) {
    writeQuery ("insert into ".$table." ".$query);
}

function deleteRow ($table, $ID) {
    writeQuery ("delete from ".$table." where ID = ".$ID);
}

function sortByName ($table, $ID, $items) {
    $rows = getRows ($table, "ID", [], "name");
    $sorted = array ();

    foreach ($rows as $row) {
        foreach ($items as $item) {
            if ($item->info[$ID] == $row["ID"]) {
                $sorted[] = $item;
            }
        }
    }
    return $sorted;
}

function sendEmail ($rid, $book) {
    $to = "katikumut@gmail.com";
    $subject = "Rental ".$rid." Demo Request";
    $msg = "Name: ".$book["name"]."\n";
    $msg .= "Phone: ".$book["phone"]."\n";
    $msg .= "Date: ".$book["date"];

    if (!mail($to, $subject, $msg))
        return false;
    return true;
}

/* premises video file uploads -> validations */

define('UPLOAD_DIRECTORY', 'vid/');
define('MAXSIZE', 200242880); // 200MB in bytes.
$ALLOWED_EXTENSIONS = array('mp4', 'ogg', 'webm');
$ALLOWED_MIMES = array('video/mp4', 'video/ogg', 'video/webm');

function validFileType($uploadedTempFile, $destFilePath) {
    global $ALLOWED_EXTENSIONS, $ALLOWED_MIMES;
    $fileExtension = pathinfo($destFilePath, PATHINFO_EXTENSION);
    $fileMime = mime_content_type($uploadedTempFile);
    $validFileExtension = in_array($fileExtension, $ALLOWED_EXTENSIONS);
    $validFileMime = in_array($fileMime, $ALLOWED_MIMES);

    return $validFileExtension && $validFileMime;
}

function handleUpload($files, $videoName) {
    $uploadedTempFile = $files['video']['tmp_name'];
    $filename = basename($files['video']['name']);
    $fileExtension = pathinfo($filename, PATHINFO_EXTENSION);
    $destFile = UPLOAD_DIRECTORY . $videoName . "." . $fileExtension;
    $isUploadedFile = is_uploaded_file($uploadedTempFile);
    $validSize = $files['video']['size'] <= MAXSIZE && $files['video']['size'] >= 0;
    
    if ($isUploadedFile && $validSize && validFileType($uploadedTempFile, $destFile)) {
        $success = move_uploaded_file($uploadedTempFile, $destFile);
        if ($success)
            return 'The file was uploaded successfully!';
        else
            return 'An unexpected error occurred; the file could not be uploaded.';            
    }
    return 'Error: the file you tried to upload is not a valid file. Check file type and size.';
}

function uploadPremisesVideo($files, $videoName) {
    switch($files['video']['error']) {
        case UPLOAD_ERR_OK:
            return handleUpload($files, $videoName);
        case UPLOAD_ERR_INI_SIZE:
            return 'Error: file size is bigger than allowed.';
        case UPLOAD_ERR_PARTIAL:
            return 'Error: the file was only partially uploaded.';
        case UPLOAD_ERR_NO_FILE:
            return 'Error: no file could have been uploaded.';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Error: no temp directory! Contact the administrator.';
        case UPLOAD_ERR_CANT_WRITE:
           return 'Error: it was not possible to write in the disk. Contact the administrator.';
        case UPLOAD_ERR_EXTENSION:
            return 'Error: a PHP extension stopped the upload. Contact the administrator.';
        default:            
            return 'An unexpected error occurred; the file could not be uploaded.';
    }
}
?>