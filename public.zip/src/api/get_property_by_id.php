<?php   
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'db.php';

$id = intval($_GET['id'] ?? 0);
$property = getRow('rentals', '*', ['ID', '=', $id]);

if (count($property)) echo json_encode($property);
else echo json_encode(["error" => "Property not found"]);
?>