<?php   
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'db.php';

$properties = getRows('rentals', '*');

echo json_encode($properties);
?>