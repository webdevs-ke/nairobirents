import { Routes } from '@angular/router';
import { PropertyList } from './components/property-list/property-list';
import { About } from './components/about/about';
import { Contact } from './components/contact/contact';
import { JoinUs } from './components/join-us/join-us';
import { Blog } from './components/blog/blog';
import { PropertyDetail } from './components/property-detail/property-detail';

export const routes: Routes = [
    {
        path: '',
        component: PropertyList
    },
    {
        path: 'about',
        component: About
    },
    {
        path: 'contact',
        component: Contact
    },  
    {
        path: 'property/:id', 
        component: PropertyDetail
    },
    {
        path: 'join-us', 
        component: JoinUs
    },
    {
        path: 'blog', 
        component: Blog
    },
    { path: '**', redirectTo: '' }
];
