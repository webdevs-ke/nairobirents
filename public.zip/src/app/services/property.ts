import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Property {
  private baseUrl = 'http://localhost/nairobirents';

  constructor(private http: HttpClient) {}

  getProperties(search?: string): Observable<any[]> {
    const url = search && search.trim()
      ? `${this.baseUrl}/get_properties.php?search=${encodeURIComponent(search.trim())}`
      : `${this.baseUrl}/get_properties.php`;
    return this.http.get<any[]>(url);
  }

  getPropertyById(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/get_property_by_id.php?id=${id}`);
  }

  uploadProperty(formData: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/upload_property.php`, formData);
  }
  
}
