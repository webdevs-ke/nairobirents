import { Component, signal, OnInit, OnDestroy, Inject, PLATFORM_ID, HostListener } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { RouterOutlet, Router } from '@angular/router';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit, OnDestroy {
  protected readonly title = signal('nairobirents');
  protected readonly numUsers = signal(473);

  isScrolled = false;
  @HostListener('window:scroll', [])

  lastScrollY = 0;
  hideHeader = false;

  onWindowScroll() {
    const scrollY = window.scrollY || document.documentElement.scrollTop;
    this.isScrolled = scrollY > 50; // toggle once user scrolls beyond 50px
  }
  
  currentUrl = '';
  facebookShareUrl = '';
  twitterShareUrl = '';
  linkedinShareUrl = '';
  whatsappShareUrl = '';
  
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private router: Router) {}
  
  private messages = [
    'Find your ideal home on your budget',
    'Affordable rental searches on your device',
    'You can join us and upload your videos or images for free',
    'Use the search tool to filter your choices',
    'An ideal home balances price and comfort',
    'Contact us for more details'
  ];
  
  currentIndex = signal(0);
  currentMessage = signal(this.messages[0]);
  private intervalId?: ReturnType<typeof setInterval>;

  searchQuery = signal<string>('');

  mobileMenuOpen = false;

  ngOnInit() {
    window.addEventListener('scroll', this.handleScroll.bind(this));
    // Change text every 3 seconds
    this.intervalId = setInterval(() => {
      let next = (this.currentIndex() + 1) % this.messages.length;
      this.currentIndex.set(next);
      this.currentMessage.set(this.messages[next]);
    }, 10000);
	
    if (isPlatformBrowser(this.platformId)) {
        const currentUrl = window.location.href;
        const encodedUrl = encodeURIComponent(currentUrl);
        const text = encodeURIComponent('Check out these rentals on Nairobirents!');

        this.currentUrl = currentUrl;
        this.facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        this.twitterShareUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${text}`;
        this.linkedinShareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        this.whatsappShareUrl = `https://api.whatsapp.com/send?text=${text}%20${encodedUrl}`;
      }
  }
  
  ngOnDestroy() {
    clearInterval(this.intervalId);
  }

  handleScroll() {
    const current = window.scrollY;
  
    if (current > this.lastScrollY && current > 320) {
      // Scrolling down → hide
      this.hideHeader = true;
    } else {
      // Scrolling up → show
      this.hideHeader = false;
    }

    this.lastScrollY = current;
  }
  onSearch(event: Event) {
    event.preventDefault();
    const input = (event.target as HTMLFormElement).querySelector('input[name="search"]') as HTMLInputElement;
    this.searchQuery.set(input.value.trim());

    // Navigate to home route (property-list component) with query params
    this.router.navigate(['/'], {
      queryParams: { search: this.searchQuery() || null },
    });
  }
}
