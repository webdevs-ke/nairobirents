import { Component, Input, Output, EventEmitter, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, CurrencyPipe } from '@angular/common';
import { TruncateWordsPipe } from  '../../pipes/truncate-words-pipe';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-property-card',
  imports: [CurrencyPipe, TruncateWordsPipe],
  templateUrl: './property-card.html',
  styleUrl: './property-card.css',
})
export class PropertyCard {
  @Input() id!: number;
  @Input() title!: string;
  @Input() description!: string;
  @Input() price!: number;
  @Input() summary!: string;
  @Input() mediaUrl!: string | string[];
  @Input() type: 'image' | 'video' = 'image';
  @Input() agentPhone!: string;
  @Input() area!: string;
  
  @Output() viewDetail = new EventEmitter<number>();

  safeMediaUrl!: SafeResourceUrl;
  currentUrl = '';

  facebookShareUrl = '';
  twitterShareUrl = '';
  linkedinShareUrl = '';
  whatsappShareUrl = '';

  toastVisible = false;
  toastTimeout!: number;
  
  galleryImages: string[] = [];
  currentImage: string = '';
  currentIndex = 0;
  loading = true;
  slideTimer: any;

  lightboxOpen = false;
  lightboxImage = '';
  lightboxIndex = 0;

  constructor(
    private sanitizer: DomSanitizer,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}
  
  ngOnInit() {
    this.agentPhone = "tel:" + this.agentPhone;
    if (this.type === 'video') {
      this.safeMediaUrl = this.getSafeMediaUrl(this.mediaUrl as string);
    } else {
      this.initGallery();
    }

     // Safely build share URLs only in browser
     if (isPlatformBrowser(this.platformId)) {
      this.currentUrl = location.href + '/property/' + this.id;
      this.updateShareUrls(this.currentUrl);
    }
  }
  
  private resolveLocalUrl(url: string): string {
    if (!url) return url;
  
    // If it already has http/https, return as-is
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
  
    // Fix missing leading slash, if needed
    if (!url.startsWith('/')) {
      url = '/' + url;
    }
  
    // Prepend your server base URL
    return `http://localhost/nairobirents${url}`;
  }
  
  private initGallery(): void {
    let urls: string[] = [];
  
    // CASE 1 — Array provided
    if (Array.isArray(this.mediaUrl)) {
      urls = this.mediaUrl;
    }
  
    // CASE 2 — Comma-separated string from backend
    else if (typeof this.mediaUrl === 'string' && this.mediaUrl.includes(',')) {
      urls = this.mediaUrl.split(',').map(u => u.trim());
    }
  
    // CASE 3 — Single string
    else if (typeof this.mediaUrl === 'string') {
      urls = [this.mediaUrl];
    }
  
    // Normalize URLs (convert "uploads/pic.jpg" to "http://localhost/nairobirents/uploads/pic.jpg")
    this.galleryImages = urls.map(url => this.resolveLocalUrl(url));
  
    // Load first image
    if (this.galleryImages.length > 0) {
      this.currentImage = this.galleryImages[0];
      this.preloadImages();
      this.autoRotate();
    }
  }
  

  private preloadImages(): void {
    const promises = this.galleryImages.map(
      (url) =>
        new Promise((resolve) => {
          const img = new Image();
          img.src = url;
          img.onload = () => resolve(true);
        })
    );

    Promise.all(promises).then(() => (this.loading = false));
  }

  nextImage(): void {
    this.currentIndex = (this.currentIndex + 1) % this.galleryImages.length;
    this.currentImage = this.galleryImages[this.currentIndex];
  }

  prevImage(): void {
    this.currentIndex =
      (this.currentIndex - 1 + this.galleryImages.length) % this.galleryImages.length;
    this.currentImage = this.galleryImages[this.currentIndex];
  }

  private autoRotate(): void {
    if (this.galleryImages.length > 1) {
      this.slideTimer = setInterval(() => this.nextImage(), 4000);
    }
  }

  openLightbox(index: number): void {
    this.lightboxIndex = index;
    this.lightboxImage = this.galleryImages[index];
    this.lightboxOpen = true;
    document.body.style.overflow = 'hidden'; // Prevent scrolling
  }
  
  closeLightbox(): void {
    this.lightboxOpen = false;
    document.body.style.overflow = 'auto';
  }
  
  lightboxNext(): void {
    this.lightboxIndex = (this.lightboxIndex + 1) % this.galleryImages.length;
    this.lightboxImage = this.galleryImages[this.lightboxIndex];
  }
  
  lightboxPrev(): void {
    this.lightboxIndex =
      (this.lightboxIndex - 1 + this.galleryImages.length) %
      this.galleryImages.length;
    this.lightboxImage = this.galleryImages[this.lightboxIndex];
  }
  
  ngOnDestroy() {
    if (this.slideTimer) clearInterval(this.slideTimer);
  }
  
  onViewDetail(): void {
    this.viewDetail.emit(this.id);
  }

  private getSafeMediaUrl(url: string): SafeResourceUrl {
    // Convert relative local paths → absolute URLs
    url = this.resolveLocalUrl(url);

    const yt = this.extractYouTubeEmbed(url);
    if (yt) return this.sanitize(yt);

    const vm = this.extractVimeoEmbed(url);
    if (vm) return this.sanitize(vm);

    const tk = this.extractTikTokEmbed(url);
    if (tk) return this.sanitize(tk);

    // Local or remote video?
    if (/\.(mp4|webm|ogg)$/i.test(url)) {
      return this.sanitize(url);
    }

    // Otherwise assume image
    return this.sanitize(url);
  }

  // YouTube detection + embed conversion
  private extractYouTubeEmbed(url: string): string | null {
    const match = url.match(
      /(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/
    );
    return match ? `https://www.youtube.com/embed/${match[1]}` : null;
  }

  // Vimeo detection + embed conversion
  private extractVimeoEmbed(url: string): string | null {
    const match = url.match(/vimeo\.com\/(\d+)/);
    return match ? `https://player.vimeo.com/video/${match[1]}` : null;
  }

  // TikTok detection + embed URL
  private extractTikTokEmbed(url: string): string | null {
    const match = url.match(/tiktok\.com\/@[\w.-]+\/video\/(\d+)/);
    return match
      ? `https://www.tiktok.com/embed/${match[1]}`
      : null;
  }

  private sanitize(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  private updateShareUrls(url: string) {
    const encoded = encodeURIComponent(url);

    this.facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encoded}`;
    this.twitterShareUrl = `https://twitter.com/intent/tweet?url=${encoded}`;
    this.linkedinShareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encoded}`;
    this.whatsappShareUrl = `https://api.whatsapp.com/send?text=${encoded}`;
  }

  async copyLink() {
    try {
      await navigator.clipboard.writeText(this.currentUrl);
      this.showToast();
    } catch (err) {
      console.error('Clipboard error:', err);
    }
  }

  showToast() {
    this.toastVisible = true;
    clearTimeout(this.toastTimeout);
    this.toastTimeout = window.setTimeout(() => {
      this.toastVisible = false;
    }, 2000);
  }
}
