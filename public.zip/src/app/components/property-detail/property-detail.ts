import { Component, OnInit, Inject, PLATFORM_ID  } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Property } from '../../services/property';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { isPlatformBrowser, CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-property-detail',
  imports: [CurrencyPipe],
  templateUrl: './property-detail.html',
  styleUrl: './property-detail.css',
})
export class PropertyDetail implements OnInit {
  property: any;
  safeMediaUrl!: SafeResourceUrl;

  constructor(
    private route: ActivatedRoute,
    private propertyService: Property,
    private sanitizer: DomSanitizer,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.propertyService.getPropertyById(id).subscribe((data) => {
      this.property = data;      
      this.safeMediaUrl = this.getSafeMediaUrl(data.mediaUrl);
    });
  }

  private getSafeMediaUrl(url: string): SafeResourceUrl {
    const yt = this.extractYouTubeEmbed(url);
    if (yt) return this.sanitize(yt);

    const vm = this.extractVimeoEmbed(url);
    if (vm) return this.sanitize(vm);

    const tk = this.extractTikTokEmbed(url);
    if (tk) return this.sanitize(tk);

    // Local or remote video?
    if (/\.(mp4|webm|ogg)$/i.test(url)) {
      return this.sanitize(url);
    }

    // Otherwise assume image
    return this.sanitize(url);
  }

  // Vimeo detection + embed conversion
  private extractVimeoEmbed(url: string): string | null {
    const match = url.match(/vimeo\.com\/(\d+)/);
    return match ? `https://player.vimeo.com/video/${match[1]}` : null;
  }

  // TikTok detection + embed URL
  private extractTikTokEmbed(url: string): string | null {
    const match = url.match(/tiktok\.com\/@[\w.-]+\/video\/(\d+)/);
    return match
      ? `https://www.tiktok.com/embed/${match[1]}` : null;
  }

  private sanitize(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
  // YouTube detection + embed conversion
  private extractYouTubeEmbed(url: string): string | null {
    const match = url.match(
      /(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/
    );
    return match ? `https://www.youtube.com/embed/${match[1]}` : null;
  }
}
