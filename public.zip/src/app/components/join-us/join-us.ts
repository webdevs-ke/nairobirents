import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpEvent, HttpEventType } from '@angular/common/http';

// import { Property } from '../../services/property';

@Component({
  selector: 'app-join-us',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './join-us.html',
  styleUrl: './join-us.css',
})
export class JoinUs implements OnInit{
  uploadForm!: FormGroup;
  previews: string[] = [];
  selectedFiles: File[] = [];
  isDragging = false;

  uploadProgress = 0;
  uploading = false;

  propertyTypes = [
    { ID: '4', name: '1 Bedroom' },
    { ID: '5', name: '2 Bedroom' },
    { ID: '6', name: '3 Bedroom' },
    { ID: '7', name: '4 Bedroom' },
    { ID: '3', name: 'Bedsitter' },
    { ID: '2', name: 'Double Room' },
    { ID: '8', name: 'Shop' },
    { ID: '1', name: 'Single Room' }
  ];  

  mediaInputType: 'upload' | 'url' = 'upload'; // user's choice

  constructor(private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    this.uploadForm = this.fb.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      rental_type: ['', Validators.required],
      price: ['', Validators.required],
      location: ['', Validators.required],
      summary: ['', Validators.required],
      uploadChoice: ['file'],
      mediaType: ['video'],
      mediaUrl: [''],
    });
  }

  // --- User toggles between URL and file upload
  onUploadChoiceChange(choice: string) {
    this.uploadForm.patchValue({ uploadChoice: choice });
    this.resetMediaSelection();
  }

  // --- User toggles between image(s) and video
  onMediaTypeChange(type: string) {
    this.uploadForm.patchValue({ mediaType: type });
    this.previews = [];
  }

  // --- Regular file input
  onFileChange(event: any): void {
    const files = event.target.files;
    this.handleFiles(files);
  }

  // --- Drag and drop handling
  @HostListener('dragover', ['$event'])
  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = true;
  }

  @HostListener('dragleave', ['$event'])
  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
  }

  @HostListener('drop', ['$event'])
  onDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) this.handleFiles(files);
  }

  removePreview(index: number): void {
    // Remove the preview URL
    this.previews.splice(index, 1);
    this.selectedFiles.splice(index, 1);
  }

  // --- Common handler for file validation and preview
  private handleFiles(fileList: FileList): void {
    const mediaType = this.uploadForm.value.mediaType;
    const acceptedType = mediaType === 'image' ? 'image/' : 'video/';
    const maxFiles = mediaType === 'image' ? 5 : 1;

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      if (!file.type.startsWith(acceptedType)) {
        alert(`Invalid file type: ${file.name}`);
        continue;
      }

      if (this.selectedFiles.length >= maxFiles) {
        alert(`You can upload a maximum of ${maxFiles} ${mediaType}(s).`);
        break;
      }

      this.selectedFiles.push(file);

      const reader = new FileReader();
      reader.onload = (e: any) => this.previews.push(e.target.result);
      reader.readAsDataURL(file);
    }
  }

  // --- Reset previews & selected files
  private resetMediaSelection(): void {
    this.previews = [];
    this.selectedFiles = [];
  }

  // --- Submit form data
  onSubmit(): void {
    if (this.uploadForm.invalid) {
      alert('Please complete the form.');
      return;
    }

    const formData = new FormData();
    const values = this.uploadForm.value;

    Object.entries(values).forEach(([key, value]) => {
      if (key !== 'mediaUrl' && key !== 'uploadChoice' && key !== 'mediaType') {
        formData.append(key, value as string);
      }
    });

    formData.append('uploadChoice', values.uploadChoice);
    formData.append('mediaType', values.mediaType);

    if (values.uploadChoice === 'url' && values.mediaUrl) {
      formData.append('media_url', values.mediaUrl);
    } else if (this.selectedFiles.length > 0) {
      console.log("File 0: ", this.selectedFiles[0]);
      this.selectedFiles.forEach((file) => formData.append('media_files[]', file));
    }

    this.uploading = true;
    this.uploadProgress = 0;

    this.http
      .post('http://localhost/nairobirents/upload_property.php', formData, {
        reportProgress: true,
        observe: 'events',
      })
      .subscribe({
        next: (event: any) => {
          if (event.type === HttpEventType.UploadProgress && event.total) {
            this.uploadProgress = Math.round((event.loaded / event.total) * 100);
          } else if (event.type === HttpEventType.Response) {
            this.uploadProgress = 100;
            setTimeout(() => (this.uploading = false), 1000);
            alert('Property uploaded successfully!');
            this.uploadForm.reset({ uploadChoice: 'file', mediaType: 'video' });
            this.resetMediaSelection();
          }
        },
        error: (err) => {
          alert('Upload failed. Please try again.');
          this.uploading = false;
          this.uploadProgress = 0;
        },
      });
  }
}
