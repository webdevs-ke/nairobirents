import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Property } from '../../services/property';
import { CommonModule } from '@angular/common';
import { PropertyCard } from '../property-card/property-card';

@Component({
  selector: 'app-property-list',
  imports: [CommonModule, PropertyCard],
  templateUrl: './property-list.html',
  styleUrl: './property-list.css',
})
export class PropertyList implements OnInit{
  properties: any[] = [];
  searchQuery: string = '';

  constructor(
    private propertyService: Property, 
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // React to query param changes
    this.route.queryParams.subscribe(params => {
      this.searchQuery = params['search'] || '';
      this.loadProperties();
    });
  }

  loadProperties(): void {
    this.propertyService.getProperties(this.searchQuery).subscribe({
      next: data => (this.properties = data),
      error: err => console.error('Error fetching properties:', err)
    });
    // console.log("Searching: ", this.searchQuery);
  }

  navigateToDetail(id: number): void {
    this.router.navigate(['/property', id]);
  }
}

