import { bootstrapApplication } from '@angular/platform-browser';

import { appConfig } from './app/app.config';
import { registerLocaleData } from '@angular/common';
import localeEnKe from '@angular/common/locales/en-KE';

import { App } from './app/app';

registerLocaleData(localeEnKe);

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
